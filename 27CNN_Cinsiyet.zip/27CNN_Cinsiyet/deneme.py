#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 20 11:19:47 2018

@author: sadievrenseker
"""

l = [0.1,0.2,0.3,0.9,0.4]
l=list(map(round,l))
print(l)